package com.tonna7sa.noticia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoticiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
