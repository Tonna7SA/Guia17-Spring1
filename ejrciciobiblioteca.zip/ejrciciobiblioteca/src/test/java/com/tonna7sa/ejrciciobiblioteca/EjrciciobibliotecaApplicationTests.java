package com.tonna7sa.ejrciciobiblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjrciciobibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
