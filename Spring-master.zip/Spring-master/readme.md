## Proyecto Biblioteca Egg
#### V1: 
Configuraciones iniciales del proyecto - Entidades, Servicios y Repositorio de Autor, Libro y Editorial.

#### V2: 
Controladores Autor, Libro y Editorial. Portal Controlador.

#### V3: 
Spring Security - Clase Usuario - Login y Registro.

#### V4: 
Carga de Imagen - clases y controlador "ResponseEntity" de Imagen
